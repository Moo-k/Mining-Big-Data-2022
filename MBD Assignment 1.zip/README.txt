Group Members:
Germin Chan a1805312 a1805312@student.adelaide.edu.au
Yuanxi Wang a1805637 a1805637@student.adelaide.edu.au

Question 3 instructions:
The input text file (100-0.txt) and exported jar file (wordcount1.jar) are in the Qn3 zip folder. The code to run standalone mode is packaged as edu.stanford.cs246.wordcount (deep in the edu folder). The output from running the code in standalone mode and pseudo-distributed mode are in the respective output folders.