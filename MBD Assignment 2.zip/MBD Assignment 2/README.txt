Group Members:
Germin Chan a1805312 a1805312@student.adelaide.edu.au
Yuanxi Wang a1805637 a1805637@student.adelaide.edu.au

Exercise 1,2,4,5:

Answered in the pdf file attached.

Exercise 3:
The write-up and friend recommendations for the 10 users given is answered in the pdf file. The source code is in the zip file attached. All log files and output are also included.