Student ID: a1805637
Email: a1805637@student.adelaide.edu.au

The solutions to exercises 2 and 3 are in the PDF file labeled 'MBD Assignment 4'. The code used for exercise 2 is in the jupyter notebook 'MBD Assignment 4 Part 2.ipynb'.