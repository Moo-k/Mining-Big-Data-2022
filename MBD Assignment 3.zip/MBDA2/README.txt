Student ID: a1805637
Email: a1805637@student.adelaide.edu.au

Answers to Question 2 are found in PageRank.pdf, answers to Question 3 are found in Clustering.pdf. PageRankResultsTruncated.pdf contains the answers to Question 2 without the full results of the pagerank algorithm (so it's not 110 pages).